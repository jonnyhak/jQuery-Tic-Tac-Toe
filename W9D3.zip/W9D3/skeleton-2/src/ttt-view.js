class View {
  constructor(game, $el) {
    this.game = game;
    this.$el = $el;

    this.setupBoard();
  }

  bindEvents() {
    const $ul = $('ul');
    $ul.on('click', 'li', e => {
      const $li = $(e.currentTarget);
      this.game.playMove($li);
      // e.currentTarget
      // $li.css('background-color', 'white')
    })
  }

  makeMove($square) {
    $('ul').on('click', 'li', e => {
      const $li = $(e.currentTarget);
  
      $li.text('x')
    })
  }

  setupBoard() {
    const $newUl = $("<ul>");
    this.$el.append($newUl); 
    for(let i=0; i<9; i++){
      $($newUl).append($("<li>")); 
    }  
    
    $('ul').on('click', 'li', e => {
      const $li = $(e.currentTarget);
  
      $li.css('background-color', 'white')
    })
  }



  

  // $(document).ready(function(){
 
  // })
}

// $('ul').on('click', 'li', e => {
//     // debugger // what is e.currentTarget here? what is e.target?
//     const $li = $(e.currentTarget)
//     $li.toggleClass('incomplete complete');
// });

module.exports = View;
