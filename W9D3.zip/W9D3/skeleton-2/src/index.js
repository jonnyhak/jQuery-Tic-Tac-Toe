const View = require("./ttt-view.js");// require appropriate file
const Game = require("./game.js");// require appropriate file

  $(() => {
    const rootEl = $('.ttt')
    const newGame = new Game();
    new View(newGame, rootEl);
    //be sure that the container element has been loaded
  });

